setwd("C:\\Users\\MSI\\OneDrive - Sri Lanka Institute of Information Technology\\Desktop\\IT24103570")

#Q1
set.seed(123)   
sample_data <- rnorm(25, mean = 45, sd = 2)
sample_data

#Q2
# H0: mean = 46
# H1: mean < 46
t_test_result <- t.test(sample_data, mu = 46, alternative = "less")

print(t_test_result)



